(() => {
"use strict";
const canvas=document.getElementById("game"),ctx=canvas.getContext("2d");
const W=canvas.width,H=canvas.height,TAU=Math.PI*2;
const $=id=>document.getElementById(id);
const phases=[
 ["Escola de Bambu","#d8efb0","#86bd72","#315b42","🎋","Aluno","roda de bambu"],
 ["Floresta","#315d43","#183b35","#a0b76a","🌳","Macaco","roda de casca de banana"],
 ["Cidade","#a9d7ed","#657e9c","#364c69","🏙️","Militar","roda de aço"],
 ["Cidade Destruída","#645b5c","#302d3b","#e26b43","🔥","Profissional","roda de aço reforçada"],
 ["Coliseu","#e7c58c","#a77b4c","#604b3a","🏛️","Guerreiro","roda de titânio"],
 ["Prefeitura","#d5c4a5","#9c7d65","#554f5d","🏢","Agente do governo","roda de meteorito"],
 ["Nave Alienígena","#183e55","#0b2038","#28d7c5","🛸","Extraterrestre","roda laser azul"],
 ["Nuvens","#b9e8ff","#78b9e4","#547da5","☁️","Guerreiro divino","roda de nuvens"],
 ["Templo Celestial","#e9d99b","#b69a52","#6e5a35","✨","Deus da roda","roda sagrada"],
 ["Mundo Celestial","#fff0b4","#d5ae58","#7b5b28","🌞","Mestre celestial","roda solar"]
];
const skinNames=["Cósmica","⚽ Bola de futebol","💿 CD","🚗 Roda de carro","🌸 Flor","☯️ Ying yang","🌀 Hélice","✴️ Shuriken","🌵 Cacto","🪃 Boomerang","⛏️ Picareta","💀 Caveira","🫧 Chiclete","🎩 Chapéu","🛑 Placa STOP","🪷 Vitória-régia","⭐ Estrela","🌙 Lua","☀️ Sol","🪐 Anel de Saturno","🌈 Arco-íris","⭕ Bambolê","🚘 Volante","⚔️ Espada","🔮 Bolinha de gude","📱 Celular","🌍 Globo","🧶 Novelo","🪀 Ioiô","🍽️ Prato","☀️ Sistema solar"];
const skinCosts=skinNames.map((_,i)=>i===0?0:30+i*13);
let state={phase:0,level:1,coins:0,lives:6,maxLives:6,upgrade:{duration:0,speed:0,lines:0},skin:0,owned:[0],tab:"upgrades",paused:false,mode:"book",reward:0,rewardValue:0};
let player, wheel, enemies=[], projectiles=[], hazards=[], particles=[], obstacles=[], gates=[], lever, boss, keys={},mouse={x:W/2,y:H/2},rightTarget=null,last=0,attackClock=0,stageTime=0,spawnClock=0,levelSeed=1,notice="",noticeTime=0;
const rand=(a,b)=>a+Math.random()*(b-a),clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y),angle=(a,b)=>Math.atan2(b.y-a.y,b.x-a.x);
function resetPlayer(){player={x:W/2,y:H/2,r:13,speed:205,invuln:0,slow:0,stun:0,aim:0};wheel={mode:"ready",x:player.x,y:player.y,vx:0,vy:0,life:0,maxLife:2.5+state.upgrade.duration*.65,speed:430+state.upgrade.speed*55,ricochets:0,returning:false,hit:new Set(),skin:state.skin};}
function addObstacle(type,x,y,w,h,extra={}){obstacles.push({type,x,y,w,h,...extra});}
function buildLevel(){
 enemies=[];projectiles=[];hazards=[];particles=[];obstacles=[];gates=[];boss=null;stageTime=0;attackClock=0;spawnClock=0;rightTarget=null;resetPlayer();
 const p=state.phase,l=state.level;levelSeed=p*10+l;
 // Outer walls are solid and reflect all wheel shots.
 const margin=28; addObstacle("wall",0,0,W,margin);addObstacle("wall",0,H-margin,W,margin);addObstacle("wall",0,0,margin,H);addObstacle("wall",W-margin,0,margin,H);
 // Phase-specific scenery and puzzle pieces, with a simple traversable central arena.
 if(p===0){addObstacle("bamboo",180,150,34,110);addObstacle("bambooStrong",720,330,34,120);addObstacle("wall",380,28,18,90);addObstacle("wall",560,482,18,90);}
 if(p===1){addObstacle("water",300,210,180,34);addObstacle("water",550,370,150,32);addObstacle("log",210,390,80,20);addObstacle("vine",430,120,90,12);}
 if(p===2){addObstacle("wall",170,150,100,35);addObstacle("wall",690,400,100,35);addObstacle("button",480,115,24,24);addObstacle("gate",470,250,20,100,{open:false,timer:0});}
 if(p===3){addObstacle("rubble",260,180,100,70);addObstacle("tnt",690,350,26,26);addObstacle("gate",470,260,20,100,{open:false,timer:0});}
 if(p===4){addObstacle("statue",280,280,34,44);addObstacle("spikes",600,140,130,25);addObstacle("spikes",600,430,130,25);}
 if(p===5){addObstacle("banner",350,140,20,280);addObstacle("bridge",650,250,24,120,{open:false});}
 if(p===6){addObstacle("glass",260,170,24,180);addObstacle("glassStrong",650,340,24,150);addObstacle("laser",480,120,8,280,{angle:Math.PI/2});addObstacle("miniShip",760,150,28,28);}
 if(p===7){addObstacle("softCloud",300,180,140,90);addObstacle("heavyCloud",620,350,110,80);addObstacle("chargedCloud",170,390,70,60);}
 if(p===8||p===9){addObstacle("protector",260,250,34,34);addObstacle("teleport",700,140,42,42,{pair:{x:760,y:450}});addObstacle("chain",500,180,100,12);if(p===9){addObstacle("clonePad",140,140,48,48);addObstacle("mirror",770,300,20,90);addObstacle("softCloud",400,390,110,70);}}
 // Level 10 is always a huge square boss arena.
 if(l===10){obstacles=obstacles.filter(o=>o.type==="wall");obstacles=[];addObstacle("wall",0,0,W,margin);addObstacle("wall",0,H-margin,W,margin);addObstacle("wall",0,0,margin,H);addObstacle("wall",W-margin,0,margin,H);addObstacle("wall",190,110,18,380);addObstacle("wall",752,110,18,380);createBoss();}
 else{
   const count=Math.min(3+Math.floor((l-1)*.65)+Math.floor(p*.55),12);
   for(let i=0;i<count;i++){
     let x=rand(110,W-110),y=rand(100,H-100);if(Math.hypot(x-W/2,y-H/2)<125){x=rand(90,180);y=rand(90,H-90);}
     const moving=(i%3===1)||(i===count-1&&l%2===0);
     enemies.push({x,y,homeX:x,homeY:y,r:15,hp:1,moving,dir:rand(0,TAU),speed:65+p*4,vision:moving?210:260,cool:rand(.4,1.8),wind:0,alive:true,stun:0});
   }
 }
 updateHUD();
}
function createBoss(){boss={x:W/2,y:145,r:34,hp:3,maxHp:3,exhaust:0,immune:true,seq:0,cool:1.4,attack:0,phase:state.phase,flash:0};}
function updateHUD(){const p=phases[state.phase];$("phaseName").textContent=p[0];$("levelInfo").textContent=`Fase ${state.phase+1} · Nível ${state.level}/10`; $("coins").textContent=state.coins;$("hearts").textContent="♥ ".repeat(Math.ceil(state.lives/2))+(state.lives%2?"½":"");$("objective").textContent=state.level===10?"Derrote o mestre da roda!":"Derrote todos os inimigos!";$("enemyCount").textContent=state.level===10?`Chefe: ${boss?boss.hp:3} / 3`:`Inimigos restantes: ${enemies.filter(e=>e.alive).length}`;$("wheelStatus").textContent=wheel?.mode==="ready"?"Roda pronta":wheel?.mode==="out"?"Roda lançada":"Roda regressando";}
function showOverlay(icon,title,text,button,extra=""){ $("overlayIcon").textContent=icon;$("overlayTitle").textContent=title;$("overlayText").textContent=text;$("overlayExtra").innerHTML=extra;$("overlayButton").textContent=button;$("overlay").classList.remove("hidden");}
function hideOverlay(){$("overlay").classList.add("hidden");}
function bookIntro(){state.mode="book";showOverlay("📖","O Livro da Roda","Antes de começares, aprende os fundamentos. Koko roubou a Roda Cósmica depois de o seu professor o chamar de inútil. Agora vai provar que pode tornar-se o maior mestre de todos.", "Começar tutorial",`<div class="book-list"><b>Controlos</b><br>• WASD ou setas: mover Koko.<br>• Mira com o rato; clique esquerdo: lançar a roda. Clique novamente: chamar/parar a roda.<br>• Botão direito: marcar destino.<br><br><b>A roda</b><br>• A roda ricocheteia nas paredes durante um tempo limitado.<br>• A linha pontilhada prevê a trajetória; upgrades aumentam duração, velocidade e linhas.<br><br><b>Objetivo</b><br>• Derrota todos os inimigos, evita ataques e usa alavancas e objetos do cenário.</div>`);}
function tutorial(){state.mode="tutorial";showOverlay("🛞","Treino básico","Move-te com WASD ou as setas. Aponta o rato e clica para lançar a roda; clica outra vez para a chamar. Derrota o alvo de treino para abrir o caminho.", "Entendi",`<div class="book-list">A roda atravessa grades e certos objetos. Atinge bambu para o partir. Mantém distância dos ataques: Koko tem 3 corações (6 meios-corações).</div>`);}
function beginGame(){state.mode="playing";hideOverlay();buildLevel();if(state.phase===0&&state.level===1)enemies=[{x:W/2+160,y:H/2,r:15,hp:1,moving:false,homeX:W/2+160,homeY:H/2,vision:300,cool:99,alive:true,stun:0}];}
function completeLevel(){if(state.mode!=="playing")return;state.mode="reward";const base=12+state.phase*14+state.level*4;state.reward=base;state.rewardValue=base;showOverlay("🏆","Nível concluído!","Todos os adversários foram derrotados. Para receber as moedas, clica quando o marcador estiver o mais perto possível do centro.", "Parar medidor",`<div class="meter"><div class="meter-track"><div id="meterNeedle" class="meter-needle"></div><div class="meter-center"></div></div><b id="rewardAmount">${base} moedas</b></div>`);let dir=1,pos=0;const needle=$("meterNeedle");const tick=()=>{if(state.mode!=="reward"||!needle)return;pos+=dir*2.3;if(pos>100||pos<0)dir*=-1;needle.style.left=pos+"%";requestAnimationFrame(tick);};requestAnimationFrame(tick);}
function claimReward(){const needle=$("meterNeedle");let pos=needle?parseFloat(needle.style.left)||50:50;const accuracy=1-Math.abs(pos-50)/50;const gain=Math.max(1,Math.round(state.reward*(.35+accuracy*.9)));state.coins+=gain;state.mode="between";if(state.level<10)state.level++;else if(state.phase<9){state.phase++;state.level=1;}else{state.mode="finished";showOverlay("👑","Mestre da Roda!","Koko derrotou o melhor do mundo e provou que a força nasce da determinação. A técnica da roda, criada para vencer guerras, tornou-se uma arte ensinada a todos.", "Jogar novamente");return;}updateHUD();showOverlay("🪙",`+${gain} moedas!`,`Recebeste ${gain} moedas. Recuperaste todos os corações. Podes visitar a loja antes do próximo nível.`, "Próximo nível",`<div class="book-list">Fase ${state.phase+1}: ${phases[state.phase][0]} · Nível ${state.level}/10</div>`);}
function lose(){state.mode="lost";showOverlay("💀","VOCÊ PERDEU","Koko ficou sem corações. Podes tentar novamente este nível; as moedas e melhorias mantêm-se.", "Reiniciar nível");}
$("overlayButton").addEventListener("click",()=>{if(state.mode==="book")tutorial();else if(state.mode==="tutorial")beginGame();else if(state.mode==="reward")claimReward();else if(state.mode==="between"){state.lives=state.maxLives;beginGame();}else if(state.mode==="lost"){state.lives=state.maxLives;beginGame();}else if(state.mode==="finished"){state={phase:0,level:1,coins:0,lives:6,maxLives:6,upgrade:{duration:0,speed:0,lines:0},skin:0,owned:[0],tab:"upgrades",mode:"book",reward:0,rewardValue:0};bookIntro();}});
function showShop(){if(state.mode!=="playing"&&state.mode!=="between")return;$("shop").classList.remove("hidden");renderShop();}
function renderShop(){document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.tab===state.tab));const c=$("shopContent");c.innerHTML="";if(state.tab==="upgrades"){const items=[["duration","Tempo de ricochete","A roda fica mais tempo ativa.",60, "s"],["speed","Velocidade da roda","Aumenta a velocidade do projétil.",55,""],["lines","Linhas de previsão","Mostra mais segmentos da trajetória.",45,""]];items.forEach(([id,name,desc,cost])=>{const lv=state.upgrade[id];const div=document.createElement("div");div.className="shop-item";div.innerHTML=`<div><b>${name} · Nv. ${lv}</b><small>${desc}</small></div><button ${state.coins<cost+lv*cost?"disabled":""}>${cost+lv*cost} 🪙</button>`;div.querySelector("button").onclick=()=>{const price=cost+lv*cost;if(state.coins>=price){state.coins-=price;state.upgrade[id]++;updateHUD();renderShop();}};c.append(div);});}else{skinNames.forEach((name,i)=>{const owned=state.owned.includes(i),cost=skinCosts[i],div=document.createElement("div");div.className="shop-item";div.innerHTML=`<div><b>${name}</b><small>${owned?"Desbloqueada":cost+" moedas"}</small></div><button ${(!owned&&state.coins<cost)?"disabled":""}>${owned?(state.skin===i?"Equipada":"Equipar"):"Comprar"}</button>`;div.querySelector("button").onclick=()=>{if(owned)state.skin=i;else if(state.coins>=cost){state.coins-=cost;state.owned.push(i);state.skin=i;}updateHUD();renderShop();};c.append(div);});}}
$("shopButton").onclick=showShop;$("closeShop").onclick=()=>$("shop").classList.add("hidden");document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{state.tab=b.dataset.tab;renderShop();});
function pointer(e){const r=canvas.getBoundingClientRect();return{x:(e.clientX-r.left)*W/r.width,y:(e.clientY-r.top)*H/r.height};}
canvas.addEventListener("mousemove",e=>mouse=pointer(e));canvas.addEventListener("contextmenu",e=>{e.preventDefault();rightTarget=pointer(e);});
canvas.addEventListener("mousedown",e=>{if(state.mode!=="playing"||!$("shop").classList.contains("hidden"))return;if(e.button===0){if(wheel.mode==="ready")launchWheel();else if(wheel.mode==="out")recallWheel();else if(wheel.mode==="return"){} }});
window.addEventListener("keydown",e=>{keys[e.key.toLowerCase()]=true;if(["arrowup","arrowdown","arrowleft","arrowright"," "].includes(e.key.toLowerCase()))e.preventDefault();if(e.key.toLowerCase()==="p"&&state.mode==="playing")state.paused=!state.paused;});window.addEventListener("keyup",e=>keys[e.key.toLowerCase()]=false);
function launchWheel(){const a=Math.atan2(mouse.y-player.y,mouse.x-player.x);wheel={...wheel,mode:"out",x:player.x,y:player.y,vx:Math.cos(a)*wheel.speed,vy:Math.sin(a)*wheel.speed,life:wheel.maxLife,ricochets:0,hit:new Set(),skin:state.skin};}
function recallWheel(){wheel.mode="return";wheel.vx=0;wheel.vy=0;}
function rectHitCircle(c,o){const x=clamp(c.x,o.x,o.x+o.w),y=clamp(c.y,o.y,o.y+o.h);return Math.hypot(c.x-x,c.y-y)<c.r;}
function solid(o){return ["wall","bamboo","bambooStrong","water","rubble","gate","glass","glassStrong","heavyCloud","spikes","statue","bridge","protector","chain"].includes(o.type)&&!o.open;}
function movePlayer(dt){let dx=(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0),dy=(keys.s||keys.arrowdown?1:0)-(keys.w||keys.arrowup?1:0);if(rightTarget){const a=angle(player,rightTarget);dx=Math.cos(a);dy=Math.sin(a);if(dist(player,rightTarget)<12)rightTarget=null;}const n=Math.hypot(dx,dy)||1;dx/=n;dy/=n;let speed=player.speed*(player.slow>0?.55:1);if(player.stun>0)return;const nx=player.x+dx*speed*dt,ny=player.y+dy*speed*dt;const old={x:player.x,y:player.y};player.x=nx;for(const o of obstacles)if(solid(o)&&rectHitCircle(player,o)){player.x=old.x;break;}player.y=ny;for(const o of obstacles)if(solid(o)&&rectHitCircle(player,o)){player.y=old.y;break;}player.x=clamp(player.x,42,W-42);player.y=clamp(player.y,42,H-42);}
function damage(amount=.5){if(player.invuln>0||state.mode!=="playing")return;state.lives=Math.max(0,state.lives-amount);player.invuln=2;updateHUD();if(state.lives<=0)lose();}
function hurtEnemy(e){if(!e.alive)return;e.hp--;if(e.hp<=0){e.alive=false;state.coins+=2+state.phase;updateHUD();}}
function wheelHits(){for(const e of enemies){if(e.alive&&dist(wheel,e)<wheel.r+e.r&&!wheel.hit.has(e)){wheel.hit.add(e);hurtEnemy(e);}}if(boss&&boss.hp>0&&boss.exhaust>0&&dist(wheel,boss)<wheel.r+boss.r){boss.hp--;boss.exhaust=0;boss.immune=true;boss.flash=.25;updateHUD();if(boss.hp<=0){boss=null;completeLevel();}}}
function updateWheel(dt){if(wheel.mode==="ready")return;if(wheel.mode==="return"){const a=angle(wheel,player),d=dist(wheel,player);wheel.x+=Math.cos(a)*620*dt;wheel.y+=Math.sin(a)*620*dt;if(d<18){wheel.mode="ready";wheel.x=player.x;wheel.y=player.y;}return;}
 wheel.x+=wheel.vx*dt;wheel.y+=wheel.vy*dt;wheel.life-=dt;
 for(const o of obstacles){if(!rectHitCircle(wheel,o))continue;
  if(o.type==="bamboo"||o.type==="glass"||o.type==="rubble"){obstacles.splice(obstacles.indexOf(o),1);break;}
  if(o.type==="tnt"){explode(o.x,o.y,100,1);obstacles.splice(obstacles.indexOf(o),1);break;}
  if(o.type==="button"){const gate=obstacles.find(a=>a.type==="gate");if(gate){gate.open=true;gate.timer=3;}break;}
  if(o.type==="laser"){o.angle+=Math.PI/4;break;}
  if(o.type==="miniShip"){const target=obstacles.find(a=>["glass","glassStrong","gate"].includes(a.type));if(target)obstacles.splice(obstacles.indexOf(target),1);break;}
  if(o.type==="chargedCloud"){explode(o.x,o.y,100,1);obstacles.splice(obstacles.indexOf(o),1);break;}
  if(["wall","bambooStrong","heavyCloud","gate","glassStrong","statue","bridge","protector","chain","spikes"].includes(o.type)){const cx=clamp(wheel.x,o.x,o.x+o.w),cy=clamp(wheel.y,o.y,o.y+o.h);if(Math.abs(wheel.x-cx)>Math.abs(wheel.y-cy))wheel.vx*=-1;else wheel.vy*=-1;wheel.ricochets++;break;}
 }
 wheelHits();if(wheel.life<=0)recallWheel();if(wheel.x<25||wheel.x>W-25)wheel.vx*=-1;if(wheel.y<25||wheel.y>H-25)wheel.vy*=-1;
}
function fire(x,y,a,speed,damageValue=.5,life=5,bounce=false,r=9,kind="wheel"){projectiles.push({x,y,vx:Math.cos(a)*speed,vy:Math.sin(a)*speed,r,life,bounce,damage:damageValue,kind,hitWall:0});}
function explode(x,y,r,damageValue){hazards.push({x,y,r,life:.35,max:.35,damage:damageValue,kind:"explosion"});for(let i=0;i<18;i++){const a=rand(0,TAU);particles.push({x,y,vx:Math.cos(a)*rand(40,180),vy:Math.sin(a)*rand(40,180),life:.5});}}
function updateProjectiles(dt){for(let i=projectiles.length-1;i>=0;i--){const p=projectiles[i];p.x+=p.vx*dt;p.y+=p.vy*dt;p.life-=dt;let wall=false;for(const o of obstacles){if(rectHitCircle(p,o)&&["wall","bambooStrong","gate","glassStrong","heavyCloud","statue","bridge"].includes(o.type)){wall=true;break;}}if(p.x<28||p.x>W-28||p.y<28||p.y>H-28)wall=true;if(wall){if(p.bounce&&p.life>0){if(p.x<35||p.x>W-35)p.vx*=-1;if(p.y<35||p.y>H-35)p.vy*=-1;p.hitWall++;}else{projectiles.splice(i,1);continue;}}if(dist(p,player)<p.r+player.r){damage(p.damage);if(p.kind==="banana")player.slow=3;projectiles.splice(i,1);continue;}if(p.life<=0)projectiles.splice(i,1);}}
function enemyAI(dt){for(const e of enemies){if(!e.alive)continue;e.cool-=dt;if(e.stun>0){e.stun-=dt;continue;}const d=dist(e,player);if(e.moving&&d<e.vision){const a=angle(e,player);e.x+=Math.cos(a)*e.speed*dt;e.y+=Math.sin(a)*e.speed*dt;}else if(e.moving){const a=angle(e,{x:e.homeX+Math.cos(stageTime+e.dir)*35,y:e.homeY+Math.sin(stageTime*.8+e.dir)*35});e.x+=Math.cos(a)*e.speed*.35*dt;e.y+=Math.sin(a)*e.speed*.35*dt;}if(d<e.vision&&e.cool<=0){e.wind=.45;e.cool=e.moving?2.5:2.1;}if(e.wind>0){e.wind-=dt;if(e.wind<=0){const a=angle(e,player);fire(e.x,e.y,a, e.moving?250:230,.5,e.moving?2.2:4.5,!e.moving, e.moving?8:10);}}}}
function bossAttack(){if(!boss)return;const p=boss.phase,a=angle(boss,player);const patterns=[
 ()=>{for(let i=-1;i<=1;i++)fire(boss.x,boss.y,a+i*.28,260,.5,3,false,9);},
 ()=>{for(let i=0;i<5;i++)setTimeout(()=>{if(state.mode==="playing"&&boss)fire(boss.x,boss.y,a,250,.5,3,false,9);},i*220);},
 ()=>{for(let i=0;i<6;i++)fire(boss.x,boss.y,i*TAU/6,220,.5,4,true,8);},
 ()=>{for(let i=0;i<5;i++)fire(boss.x,boss.y,a+(i-2)*.2,220,.5,5,true,9);},
 ()=>{fire(boss.x,boss.y,a,180,1,7,true,19,"giant");explode(player.x,player.y,55,.5);},
 ()=>{for(let i=0;i<10;i++)fire(boss.x,boss.y,i*TAU/10,240,.5,3,false,7);},
 ()=>{for(let i=0;i<12;i++)fire(boss.x,boss.y,i*TAU/12,250,.25,3,true,6,"laser");},
 ()=>{for(let i=0;i<8;i++){const aa=i*TAU/8;fire(boss.x,boss.y,aa,210,.5,5,true,9);}hazards.push({x:player.x,y:player.y,r:38,life:.8,max:.8,damage:.5,kind:"target"});},
 ()=>{for(let i=0;i<3;i++)fire(boss.x,boss.y,a+(i-1)*.4,280,.5,3,true,10);},
 ()=>{for(let i=0;i<4;i++)fire(boss.x,boss.y,a+i*TAU/4,240,.5,5,true,11);}
 ];
 // Later bosses combine denser patterns and extra telegraphed hazards.
 const count=[3,3,4,5,6,6,7,8,9,10][p], pattern=patterns[(boss.seq+(p*2))%patterns.length];pattern();
 if(p>=3){for(let i=0;i<Math.min(4,p-2);i++){const x=rand(90,W-90),y=rand(90,H-90);hazards.push({x,y,r:32,life:.9,max:.9,damage:.5,kind:"target"});}}
 if(p>=6){for(let i=0;i<Math.min(p-5,4);i++)fire(boss.x,boss.y,rand(0,TAU),230,.25,4,true,6,"laser");}
 boss.seq++;boss.cool=3;
}
function updateBoss(dt){if(!boss)return;boss.cool-=dt;if(boss.exhaust>0){boss.exhaust-=dt;if(boss.exhaust<=0)boss.immune=true;}if(boss.cool<=0&&boss.exhaust<=0)bossAttack();if(boss.flash>0)boss.flash-=dt;}
function updateHazards(dt){for(let i=hazards.length-1;i>=0;i--){const h=hazards[i];h.life-=dt;if(h.kind==="target"&&h.life<.35)h.kind="explosion";if(dist(h,player)<h.r+player.r&&h.kind==="explosion")damage(h.damage);if(h.life<=0)hazards.splice(i,1);}}
function collidePlayer(){for(const o of obstacles){if(o.type==="spikes"&&rectHitCircle(player,o))damage(.5);if(o.type==="tnt"&&rectHitCircle(player,o)){}if(o.type==="teleport"&&dist(player,{x:o.x+o.w/2,y:o.y+o.h/2})<25&&o.pair){const old={x:player.x,y:player.y};player.x=o.pair.x;player.y=o.pair.y;o.pair={x:old.x,y:old.y};}if(o.type==="clonePad"&&rectHitCircle(player,o))notice="Plataforma de clonagem ativada!";}}
function update(dt){if(state.mode!=="playing"||state.paused)return;stageTime+=dt;if(player.invuln>0)player.invuln-=dt;if(player.slow>0)player.slow-=dt;if(player.stun>0)player.stun-=dt;movePlayer(dt);updateWheel(dt);enemyAI(dt);updateBoss(dt);updateProjectiles(dt);updateHazards(dt);collidePlayer();for(const o of obstacles)if(o.timer>0){o.timer-=dt;if(o.timer<=0)o.open=false;}for(let i=particles.length-1;i>=0;i--){const q=particles[i];q.x+=q.vx*dt;q.y+=q.vy*dt;q.life-=dt;if(q.life<=0)particles.splice(i,1);}if(state.level!==10&&enemies.every(e=>!e.alive))completeLevel();updateHUD();}
function drawBackground(){const p=phases[state.phase];ctx.fillStyle=p[1];ctx.fillRect(0,0,W,H);ctx.fillStyle=p[2];for(let i=0;i<12;i++){const x=(i*137+37)%W,y=(i*83+20)%H;ctx.globalAlpha=.18;ctx.beginPath();ctx.arc(x,y,24+(i%4)*9,0,TAU);ctx.fill();}ctx.globalAlpha=1;
 ctx.fillStyle=p[3];ctx.globalAlpha=.16;for(let i=0;i<8;i++){ctx.fillRect(i*130+20,0,3,H);ctx.fillRect(0,i*90+20,W,2);}ctx.globalAlpha=1;
 ctx.font="24px sans-serif";for(let i=0;i<7;i++)ctx.fillText(p[4],35+i*145,52+(i%2)*28);
}
function drawObstacles(){for(const o of obstacles){ctx.save();let color="#59677c";if(o.type==="wall")color=phases[state.phase][3];if(o.type==="bamboo")color="#b9a35b";if(o.type==="bambooStrong")color="#80612e";if(o.type==="water")color="#4ba9dc";if(o.type==="log")color="#8c5d36";if(o.type==="vine")color="#2f8c52";if(o.type==="gate")color=o.open?"#70d99b":"#49556b";if(o.type==="rubble")color="#786c6b";if(o.type==="tnt")color="#d64b3e";if(o.type==="spikes")color="#f6d05a";if(o.type==="statue")color="#e8bd45";if(o.type==="glass"||o.type==="glassStrong")color="#8ceaff";if(o.type==="laser")color="#ff4f8b";if(o.type==="miniShip")color="#55e7db";if(o.type==="softCloud"||o.type==="heavyCloud"||o.type==="chargedCloud")color=o.type==="chargedCloud"?"#f7e46b":"#f4fbff";if(o.type==="protector")color="#d2b4ff";if(o.type==="teleport"||o.type==="clonePad")color="#bd86ff";if(o.type==="mirror")color="#8af4ff";ctx.fillStyle=color;ctx.globalAlpha=o.type==="banner"?.35:.95;ctx.fillRect(o.x,o.y,o.w,o.h);ctx.globalAlpha=1;ctx.strokeStyle="#17213b99";ctx.lineWidth=2;ctx.strokeRect(o.x,o.y,o.w,o.h);if(o.type==="tnt"||o.type==="teleport"||o.type==="clonePad")ctx.fillText(o.type==="tnt"?"TNT":o.type==="teleport"?"↔":"⧉",o.x+3,o.y+o.h-5);if(o.type==="spikes"){ctx.fillStyle="#fff1a6";for(let x=o.x;x<o.x+o.w;x+=18){ctx.beginPath();ctx.moveTo(x,o.y+o.h);ctx.lineTo(x+9,o.y);ctx.lineTo(x+18,o.y+o.h);ctx.fill();}}ctx.restore();}}
function drawWheelPath(){if(wheel.mode!=="ready")return;const a=angle(player,mouse);ctx.save();ctx.strokeStyle="#126bd9";ctx.lineWidth=2;ctx.setLineDash([6,6]);ctx.beginPath();ctx.moveTo(player.x,player.y);let x=player.x,y=player.y,dx=Math.cos(a),dy=Math.sin(a);ctx.lineTo(x+dx*130,y+dy*130);for(let i=0;i<state.upgrade.lines;i++){x+=dx*130;y+=dy*130;if(x<35||x>W-35)dx*=-1;if(y<35||y>H-35)dy*=-1;ctx.moveTo(x,y);ctx.lineTo(x+dx*90,y+dy*90);}ctx.stroke();ctx.setLineDash([]);ctx.restore();}
function drawWheel(x,y,r,skin=0){ctx.save();ctx.translate(x,y);ctx.rotate(performance.now()/500);ctx.fillStyle=skin===0?"#168dff":"#e9f6ff";ctx.strokeStyle=skin===0?"#8cecff":"#24528c";ctx.lineWidth=4;ctx.beginPath();ctx.arc(0,0,r,0,TAU);ctx.fill();ctx.stroke();ctx.strokeStyle="#fff";ctx.lineWidth=2;for(let i=0;i<6;i++){ctx.rotate(TAU/6);ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(r-2,0);ctx.stroke();}ctx.fillStyle="#123a75";ctx.beginPath();ctx.arc(0,0,r*.25,0,TAU);ctx.fill();if(skin>0){ctx.font=`${r*1.05}px sans-serif`;ctx.textAlign="center";ctx.textBaseline="middle";ctx.fillText(["","⚽","💿","🚗","🌸","☯️","🌀","✴️","🌵","🪃","⛏️","💀","🫧","🎩","🛑","🪷","⭐","🌙","☀️","🪐","🌈","⭕","🚘","⚔️","🔮","📱","🌍","🧶","🪀","🍽️","☀️"][skin],0,0);}ctx.restore();}
function draw(){drawBackground();drawObstacles();drawWheelPath();for(const h of hazards){ctx.fillStyle=h.kind==="target"?"#ff303866":"#ff9a2c66";ctx.beginPath();ctx.arc(h.x,h.y,h.r,0,TAU);ctx.fill();if(h.kind==="target"){ctx.strokeStyle="#e51e35";ctx.lineWidth=3;ctx.beginPath();ctx.arc(h.x,h.y,h.r*.7,0,TAU);ctx.moveTo(h.x-h.r,h.y);ctx.lineTo(h.x+h.r,h.y);ctx.moveTo(h.x,h.y-h.r);ctx.lineTo(h.x,h.y+h.r);ctx.stroke();}}
 for(const e of enemies){if(!e.alive)continue;ctx.fillStyle=e.moving?"#a94b35":"#6b4caa";ctx.beginPath();ctx.arc(e.x,e.y,e.r,0,TAU);ctx.fill();ctx.strokeStyle="#fff";ctx.lineWidth=2;ctx.stroke();ctx.font="18px sans-serif";ctx.textAlign="center";ctx.fillText(["🎒","🐒","🪖","🥷","⚔️","🏛️","👽","☁️","✨","🌟"][state.phase],e.x,e.y+6);ctx.strokeStyle="#ef5366";ctx.lineWidth=2;ctx.beginPath();ctx.arc(e.x,e.y,e.vision,-.5,.5);ctx.stroke();if(e.wind>0){ctx.fillStyle="#ffdb66";ctx.beginPath();ctx.arc(e.x,e.y,e.r+8,0,TAU);ctx.fill();}}
 if(boss){ctx.fillStyle=boss.flash>0?"#fff":"#6c39b7";ctx.beginPath();ctx.arc(boss.x,boss.y,boss.r,0,TAU);ctx.fill();ctx.strokeStyle=boss.immune?"#6de9ff":"#ffdc65";ctx.lineWidth=6;ctx.stroke();ctx.font="34px sans-serif";ctx.textAlign="center";ctx.fillText(["👨‍🏫","🦍","🎖️","🥷","⚔️","👑","👾","🌩️","🔱","🌞"][state.phase],boss.x,boss.y+12);ctx.fillStyle="#17213b";ctx.fillRect(310,22,340,15);ctx.fillStyle="#ff5874";ctx.fillRect(310,22,340*(boss.hp/3),15);ctx.strokeStyle="#fff";ctx.strokeRect(310,22,340,15);ctx.fillStyle="#fff";ctx.font="12px Nunito";ctx.fillText(boss.exhaust>0?"EXAUSTO — ATACA AGORA!":"ESCUDO ATIVO",480,17);}
 for(const p of projectiles){ctx.fillStyle=p.kind==="laser"?"#4ceeff":p.kind==="giant"?"#ffad42":"#f5f7ff";ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,TAU);ctx.fill();ctx.strokeStyle="#334b77";ctx.stroke();}
 if(wheel.mode!=="ready")drawWheel(wheel.x,wheel.y,12,wheel.skin);drawWheel(player.x,player.y,13,0);
 ctx.fillStyle="#fff";ctx.font="bold 12px Nunito";ctx.textAlign="center";ctx.fillText("KOKO",player.x,player.y-22);
 if(player.invuln>0&&Math.floor(performance.now()/90)%2===0){ctx.strokeStyle="#fff";ctx.lineWidth=3;ctx.beginPath();ctx.arc(player.x,player.y,23,0,TAU);ctx.stroke();}
 for(const q of particles){ctx.fillStyle="#ffd45a";ctx.globalAlpha=Math.max(0,q.life*2);ctx.fillRect(q.x,q.y,4,4);ctx.globalAlpha=1;}
 if(state.paused){ctx.fillStyle="#07152dcc";ctx.fillRect(0,0,W,H);ctx.fillStyle="#fff";ctx.font="bold 44px Nunito";ctx.textAlign="center";ctx.fillText("PAUSADO",W/2,H/2);}
}
function frame(t){const dt=Math.min((t-last)/1000||0,.033);last=t;update(dt);draw();requestAnimationFrame(frame);}
bookIntro();requestAnimationFrame(frame);
})();